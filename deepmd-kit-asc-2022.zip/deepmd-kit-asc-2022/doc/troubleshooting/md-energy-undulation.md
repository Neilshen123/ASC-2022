# The temperature undulates violently during early stages of MD

This is probably because your structure is too far from the equlibrium configuration.

Although, to make sure the potential model is truly accurate, we recommend to check model deviation.
