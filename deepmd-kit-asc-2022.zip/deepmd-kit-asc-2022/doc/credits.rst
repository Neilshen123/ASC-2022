*******************
Authors and Credits
*******************

Package Contributors
=========================

* AnguseZhang
* baohan
* bwang-ecnu
* denghuilu
* frankhan91
* GeiduanLiu
* gzq942560379
* Han Wang
* haidi-ustc
* hlyang1992
* hsulab
* iProzd
* Jiequn Han
* JiabinYang
* jxxiaoshaoye
* Linfeng Zhang
* marian-code
* njzjz
* Nick Lin
* pkulzy
* Shaochen Shi
* tuoping
* wsyxbcl
* Xia, Yu
* Ye Ding
* Yingze Wang
* Yixiao Chen
* YWolfeee
* Zhanlue Yang
* zhouwei25
* ZiyaoLi

Other Credits
=============

* Zhang ZiXuan for designing the Deepmodeling logo.
* Everyone on the `Deepmodeling mailing list` for contributing to many discussions and decisions!

(If you have contributed to the ``deepmd-kit`` core package and your name is missing,
please send an email to the contributors, or
open a pull request in the `deepmd-kit repository <https://github.com/deepmodeling/deepmd-kit>`_)
