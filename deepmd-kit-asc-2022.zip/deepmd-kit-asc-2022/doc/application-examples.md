# Application Examples

## Dipole and polarizability model training

## Training with non-periodic systems

## MD on different hardware platforms

There is a scheme to generate doc html from python scripts provided in the ../examples/ directory, so that each case in doc has a counter part in ../examples.

This scheme is implemented with sphinx-gallery.

Do we want to use this ???
