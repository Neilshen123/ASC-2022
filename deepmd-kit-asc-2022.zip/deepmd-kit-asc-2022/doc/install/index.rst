Installation
============

.. toctree::
   :maxdepth: 1

   easy-install
   install-from-source
   install-lammps
   install-ipi
   install-gromacs
   build-conda
