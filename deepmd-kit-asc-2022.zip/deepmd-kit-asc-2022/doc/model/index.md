# Model

- [Overall](overall.md)
- [Descriptor `"se_e2_a"`](train-se-e2-a.md)
- [Descriptor `"se_e2_r"`](train-se-e2-r.md)
- [Descriptor `"se_e3"`](train-se-e3.md)
- [Descriptor `"hybrid"`](train-hybrid.md)
- [Fit energy](train-energy.md)
- [Fit `tensor` like `Dipole` and `Polarizability`](train-fitting-tensor.md)
- [Train a Deep Potential model using `type embedding` approach](train-se-e2-a-tebd.md)