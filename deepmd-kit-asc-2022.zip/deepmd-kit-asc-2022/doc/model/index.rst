Model
=====

.. toctree::
   :maxdepth: 1

   overall
   train-se-e2-a
   train-se-e2-r
   train-se-e3
   train-hybrid
   train-energy
   train-fitting-tensor
   train-se-e2-a-tebd